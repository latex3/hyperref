The zip archive here contains the sources for the paper.pdf and
slides.pdf files in the hyperref distribution.

Ultimately, the goal is for this information to be integrated into the
manual.  Hopefully these files will be useful for anyone wishing to work
on that -- if you are interested, please contact Heiko.  They probably
do not compile with current TeX systems.

These files are 
Copyright 1999, 2007 Heiko Oberdiek.
You may freely use, modify and/or distribute each of them.
